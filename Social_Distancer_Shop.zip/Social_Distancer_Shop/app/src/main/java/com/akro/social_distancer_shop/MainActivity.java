package com.akro.social_distancer_shop;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {
    EditText EditTextShopName, EditTextShopAddress,EditTextproduct,EditTextQuantity;
    Button Submit;
    DatabaseReference DatabaseShop;
    Member member;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditTextShopName = (EditText) findViewById(R.id.Name);
        EditTextShopAddress = (EditText) findViewById(R.id.Address);
        EditTextproduct = (EditText) findViewById(R.id.product1);
        EditTextQuantity = (EditText) findViewById(R.id.Quantity);
        Submit = (Button) findViewById(R.id.Submit);
        member = new Member();
        DatabaseShop = FirebaseDatabase.getInstance().getReference().child("member");


        Submit.setOnClickListener (View -> {
            member.setName(EditTextShopName.getText().toString().trim());
            member.setAddress(EditTextShopAddress.getText().toString().trim());
            member.setProduct1(EditTextproduct.getText().toString().trim());
            member.setQuantity(EditTextQuantity.getText().toString().trim());

            DatabaseShop.push().setValue(member);
            Toast.makeText(MainActivity.this,"Submitted Successfully",Toast.LENGTH_LONG).show();
        });

    }
}