package com.akro.social_distancer_shop;

import android.text.Editable;

public class Member {
    public String Name;
    public String Address;
    public String product1;
    public String Quantity;

    public Member(String name, String address) {
        this.Name = name;
        this.Address = address;



    }



    public String getProduct1() {
        return product1;
    }

    public void setProduct1(String product1) {
        this.product1 = product1;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        Quantity = quantity;
    }
    public Member() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }
}

